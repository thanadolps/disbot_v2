#![deny(unused_must_use)]
mod braille;

use serenity::async_trait;
use serenity::client::{Client, Context, EventHandler};
use serenity::framework::standard::{macros::{command, group}, Args, CommandResult, StandardFramework, CommandError};
use serenity::model::channel::Message;

use futures::TryStreamExt;
use image::GenericImageView;
use serenity::futures::StreamExt;
use serenity::static_assertions::_core::time::Duration;
use serenity::utils::MessageBuilder;
use std::env;
use serenity::builder::CreateMessage;
use std::collections::HashSet;
use std::future::Future;
use std::error::Error;
use std::fmt::Display;

#[group]
#[commands(countdown, unicode)]
struct General;

struct Handler;

#[async_trait]
impl EventHandler for Handler {}

#[tokio::main]
async fn main() {
    dotenv::dotenv().expect(".env");

    let framework = StandardFramework::new()
        .configure(|c| c.prefix("~")) // set the bot's prefix to "~"
        .group(&GENERAL_GROUP);

    // Login with a bot token from the environment
    let token = env::var("DISCORD_TOKEN").expect("token");
    let mut client = Client::builder(token)
        .event_handler(Handler)
        .framework(framework)
        .await
        .expect("Error creating client");

    // start listening for events by starting a single shard
    if let Err(why) = client.start().await {
        println!("An error occurred while running the client: {:?}", why);
    }
}

#[command]
#[num_args(1)]
async fn countdown(ctx: &Context, msg: &Message, mut args: Args) -> CommandResult {
    let sec = match args.single::<u8>() {
        Ok(sec) => sec,
        Err(err) => {
            msg.reply(ctx, err.to_string()).await?;
            return Err(err.into());
        }
    };

    let mut message = msg.reply(ctx, "Counting...").await?;
    let mut interval = tokio::time::interval(Duration::from_secs(1));

    for i in 1..=sec {
        let tick = interval.tick().fuse();
        let delay = tokio::time::sleep(Duration::from_millis(200)).fuse();
        futures::pin_mut!(tick, delay);

        futures::select! {
            () = delay => { tick.await; },
            (_) = tick => { continue; },
        }

        let content = format!("{} second has passed...", i);
        message.edit(ctx, |m| m.content(content)).await?;
    }

    let old_content = format!("{} second has passed...", sec);
    let content = MessageBuilder::new()
        .user(&msg.author)
        .push_line("")
        .push_bold_line(old_content)
        .build();

    message.edit(ctx, |m| m.content(content)).await?;

    Ok(())
}

fn print_error<T, E: Display>(result: &Result<T, E>)
{
    if let Err(e) = &result {
        println!("{}", e);
    }
}

#[command]
async fn unicode(ctx: &Context, msg: &Message, mut args: Args) -> CommandResult {
    let res = unicode_inner(ctx, msg, args).await;
    print_error::<(), CommandError>(&res);
    res?;
    println!("Done");
    Ok(())
}


async fn unicode_inner(ctx: &Context, msg: &Message, mut args: Args) -> CommandResult {

    const DISCORD_MESSAGE_LIMIT: u32 = 2000;
    const DISCORD_WIDTH_LIMIT: u32 = 70;

    // TODO: make a more solid solution
    let arg_set = args.iter().take(10).filter_map(|x| x.ok()).collect::<HashSet<String>>();
    let invert = arg_set.contains("invert");
    let monospace = !arg_set.contains("pad");

    let maybe_image = msg.attachments.iter().find_map(|attach| {
        attach.width?;
        attach.height?;
        Some((
            image::ImageFormat::from_path(&attach.filename).ok()?,
            attach,
        ))
    });


    if let Some((format, image)) = maybe_image {
        let image_data = image.download().await?;

        let image = image::load_from_memory_with_format(&image_data, format)?;

        // let (w2, h2) = braille::calculate_image_size(image.dimensions(), 2000);

        // TODO: allow resizing by char width & using multiple message to bypass character limit
        let (w, h) = image.dimensions();
        let n_char_in_row = DISCORD_WIDTH_LIMIT;
        let row_per_message = (DISCORD_MESSAGE_LIMIT/n_char_in_row) as usize;
        let w2 = 2 * n_char_in_row; // one braille = 2 px width
        let h2= (h * w2)/w; // maintain aspect ratio


        let mut image = image
            .resize(w2, h2, image::imageops::FilterType::CatmullRom)
            .to_luma8();

        image::imageops::dither(&mut image, &image::imageops::BiLevel);


        let config = braille::BrailleConfig {
            monospace,
            invert,
            ..Default::default()
        };
        dbg!(&config);

        let mut out = String::with_capacity((3 * DISCORD_MESSAGE_LIMIT) as usize);

        let mut pat_iter = braille::image_to_patterns(&image, &config);

        loop {
            pat_iter.by_ref().take(row_per_message).for_each(|row| {
                out.extend(row);
                out += "\n";
            });

            if out.is_empty() { break; }

            msg.channel_id.send_message(
                ctx,
                |builder| builder.content(&out)
            ).await?;


            out.clear();
        }
    }
    else {
        println!("Not an Image");
    };

    Ok(())
}
